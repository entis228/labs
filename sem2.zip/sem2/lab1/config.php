<?php
return[
    'host'=>'localhost',
    'db_name' => 'itechlb1sem2',
    'username'=>'root',
    'password'=>'',
    'charset'=>'utf8'
];