<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Работа с PDO</title>
    <style></style>
</head>
<body>
<?php 
include 'DataBase.php';
$db = new Database();
?>
Таблица чемпионата выбранной лиги:
<form action="" method="post">
<select name="league" id="league">
<?php
    $leagues = $db->query("SELECT DISTINCT league FROM team");
    for($i=0;$i<count($leagues);$i++){
        echo "<option value=".($leagues[$i])["league"].">".($leagues[$i])["league"]."</option>";
    }
?>
</select>
<input type="submit" value="Отправить">
</form>
<p></p>
Cписок игр на указанный временной интервал:
<p></p>
(Формат год-месяц-день например 2020-07-21)
<form action="" method="post">
<!--Начальное время-->
<input type="text" name="in1">
<!--<p></p>-->
<!--Конечное время-->
<input type="text" name="in2">
<!--<p></p>-->
<input type="submit" value="Отправить">
</form>

<p></p>
Cписок игр выбранного футболиста:
<form action="" method="post">
<select name="footbalman" id="man">
<?php
    $mans = $db->query("SELECT DISTINCT name FROM player");
    for($i=0;$i<count($mans);$i++){
        echo "<option value=".($mans[$i])["name"].">".($mans[$i])["name"]."</option>";
    }
?>
</select>
<input type="submit" value="Отправить">
</form>
<p><p></p></p>
<?php
echo '<pre>';
#print_r($_POST);
if(array_key_exists("league",$_POST)){
$format = "SELECT name FROM team WHERE league = '%s'";
$res = $db->query(sprintf($format,$_POST['league']));
for($i=0;$i<count($res);$i++){
    echo ($res[$i])['name']."<p></p>";
}
#print_r($res);
}else{
    if(array_key_exists("footbalman",$_POST)){
        $format = "SELECT * from game inner join player on ((game.FID_Team1 = player.FID_Team)or(game.FID_Team2 = player.FID_Team))where player.name='%s'";
$res = $db->query(sprintf($format,$_POST['footbalman']));
#print_r($_POST);
for($i=0;$i<count($res);$i++){
    $it=0;
    foreach($res[$i] as $myarr){
    echo $myarr."<p></p>";
    $it++;
    if($it===6)
    break;
    }
}
#print_r($res);
}else{
    $format = "SELECT * FROM game WHERE date BETWEEN '%s' AND '%s'";
    $res = $db->query(sprintf($format,$_POST['in1'],$_POST['in2']));
    for($i=0;$i<count($res);$i++){
        #$it=0;
        foreach($res[$i] as $myarr){
        echo $myarr."<p></p>";
        #$it++;
        #if($it===6)
        #break;
        }
    }
}}
#print_r($res);
?>
</body>
</html>