<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MongoDB</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="localStorage.js"></script>
    <script>
    var ajax = new XMLHttpRequest();
    function load(){
        var zn = document.getElementById('league').value;
        localStorage.setItem('baseLeague',zn);
        //console.log(zn);
        ajax.open('GET','test.php?league='+zn);
        ajax.onreadystatechange=function(){
            if(ajax.readyState == 4){
                //console.log(ajax);
                if(ajax.status == 200){
                    console.log(ajax);
                    var res1=document.getElementById('tab1');
                    res1.innerHTML=ajax.responseText;
                }
            }
        }
        ajax.send();
    }
    function load1(){
        var zn = document.getElementById('team1').value;
        localStorage.setItem('baseTeam1',zn);
        ajax.open('GET','sel2.php?team1='+zn);
        ajax.onreadystatechange=function(){
            if(ajax.readyState == 4){
                //console.log(ajax);
                if(ajax.status == 200){
                    var result="";
                    console.log(ajax);
                    var res1=document.getElementById('sel1');
                    var xmlDoc = ajax.responseXML;
                    var rows = xmlDoc.firstChild.children;
                    for(var i=0;i<rows.length;i++){
                        result+=rows[i].children[0].firstChild.nodeValue+"<p></p>";
                    }
                    res1.innerHTML=result;
                }
            }
        }
        ajax.send();
    }
    function load2(){
        var zn = document.getElementById('team2').value;
        localStorage.setItem('baseTeam2',zn);
        ajax.open('GET','sel3.php?team2='+zn);
        ajax.onreadystatechange=function(){
            if(ajax.readyState == 4){
                //console.log(ajax);
                if(ajax.status == 200){
                    console.log(ajax);
                    var res1=document.getElementById('sel2');
                    var table = JSON.parse(ajax.response);
                    var out = "";
                    for(let i in table){
                        var tstr1=JSON.parse(table[i]);
                       // out+="<tr><td>"+tstr1+"</tr></td>";
                        out+="<tr><td>"+tstr1.date+"</td><td>"+tstr1.team1+" vs "+tstr1.team2+"</td></tr>"
                    }
                    res1.innerHTML=out;
                }
            }
        }
        ajax.send();
    }
    </script>
</head>
<body>
<?php
require 'vendor/autoload.php';
$client = new MongoDB\Client;#('mongodb://localhost:27017');
$db = $client->itlab2;
?>
<h2>Таблица чемпионата для выбранной лиги</h2>
<select name="league" id="league">
<?php
$leagues=$db->games->distinct('league');
for($i=0;$i<count($leagues);$i++){
    echo "<option value=".($leagues[$i]).">".($leagues[$i])."</option>";
}
?>
</select>
<input type="button" onclick="load()" value="Отправить">
<table bordercolor="black" border="1" width="100%">
<thead>
<tr><td align="center" colspan="5">Таблица чемпионата</td></tr>
<tr align="center">
<td>Лига</td>
<td>Дата игры</td>
<td>Место проведения</td>
<td>Команды</td>
<td>Победитель</td>
</tr>
</thead>
<tbody id="tab1"></tbody>
</table>
<h2>Список футболистов указаной команды</h2>
<select name="team1" id="team1">
<?php
$commands =$db->commands->distinct('name');
for($i=0;$i<count($commands);$i++){
    echo "<option value=".($commands[$i]).">".($commands[$i])."</option>";
}
?>
</select>
<input type="button" onclick="load1()" value="Отправить">
<div id="sel1"></div>
<h2>Список игр, в которых учавствовала выбраная команда</h2>
<select name="team2" id="team2">
<?php
$commands =$db->commands->distinct('name');
for($i=0;$i<count($commands);$i++){
    echo "<option value=".($commands[$i]).">".($commands[$i])."</option>";
}
?>
</select>
<input type="button" onclick="load2()" value="Отправить">
<p></p>
<table bordercolor="black" border="1">
<thead><tr><td>Дата</td><td>Игра</td></tr></thead>
<tbody id="sel2"></tbody>
</table>
<script>
var baseLeague = localStorage.getItem('baseLeague');
if(baseLeague!=null){
document.getElementById('league').value=baseLeague;}
var baseTeam1 = localStorage.getItem('baseTeam1');
if(baseTeam1!=null){
document.getElementById('team1').value=baseTeam1;}
var baseTeam2 = localStorage.getItem('baseTeam2');
if(baseTeam2!=null){
document.getElementById('team2').value=baseTeam2;}
</script>
</body>
</html>

