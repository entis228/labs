<?php
require 'vendor/autoload.php';
//echo $_GET['league'];
$client = new MongoDB\Client;#('mongodb://localhost:27017');
$db = $client->itlab2;
$league=$_GET['league'];
//echo $league;
if(isset($league)){
    $res1=$db->games->find(
    [
        'league' => $league,
    ],
    [
        'projection' => [
            '_id' => 0,
        ]
    ]);
    foreach($res1 as $it){
        echo "<tr align=\"center\">";
        echo "<td>".$it['league']."</td>"."<td>".$it['date']."</td>"."<td>".$it['location']."</td>"."<td>".$it['teams'][0]." vs ".$it['teams'][1]."</td>"."<td>".$it['winner']."</td>";
        echo "</tr>";
    }
    
 }