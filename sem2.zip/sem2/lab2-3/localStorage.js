function saveLocal(field, value){
    localStorage.setItem(field,value);
}
function loadLocal(field){
    return localStorage.getItem(field);
}
function setDefault(){
    if(loadLocal('baseLeague')==null){
    localStorage.setItem('baseLeague','');
}
}

