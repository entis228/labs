<?php
require 'vendor/autoload.php';
//echo $_GET['league'];
$client = new MongoDB\Client;#('mongodb://localhost:27017');
$db = $client->itlab2;
$team=$_GET['team1'];
if(isset($team)){
    
    $res2=$db->commands->find(
        [
            'name' => $team,
        ],
        [
            'projection' => [
                'players' => 1,
            ]
        ]);
header('Content-Type: text/xml');
header("Cache-Control: no-cache, must-revalidate");
echo '<?xml version="1.0" encoding="utf8"?>';
echo "<root>";
#foreach ($timetable as $row)
#{
#$NurseName=$row[0]; $Date=$row[1]; $Department=$row[2]; $Shift=$row[3];
#print "<row><NurseName>$NurseName</NurseName><Date>$Date</Date><Department>$Department</Department><Shift>$Shift</Shift></row>";
#}
foreach($res2 as $it){ 
    for($i=0;$i<count($it);$i++){
        $player=$it['players'][$i];
        print "<row><playerFName>$player</playerFName></row>";
        #echo $it['players'][$i],"<p></p>";
    }
}
echo "</root>";

        
  #      foreach($res2 as $it){
   #         for($i=0;$i<count($it);$i++){
    #        echo $it['players'][$i],"<p></p>";
     #       }
      #  }
}