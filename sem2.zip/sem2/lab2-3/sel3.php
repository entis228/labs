<?php
require 'vendor/autoload.php';
//echo $_GET['league'];
$client = new MongoDB\Client;#('mongodb://localhost:27017');
$db = $client->itlab2;
$team=$_GET['team2'];
if(isset($team)){
    $res3 = $db->games->find(
        array("teams"=>$team)    
    );
    header('Content-Type:application/json');
    header("Cache-Control: no-cache, must-revalidate");
    $ii=0;
    $mas;
    foreach($res3 as $it){
        $mas[$ii]=json_encode(array('date'=>$it['date'],'team1'=>$it['teams'][0],'team2'=>$it['teams'][1]));
        $ii++;
    }
    echo json_encode($mas);
       # foreach($res3 as $it){
        #    echo "<tr>";
         #   echo "<td>",$it['date'],"</td>","<td>",$it['teams'][0]," vs ",$it['teams'][1],"</td>";
        #}
        #var_dump($res3);
    }
